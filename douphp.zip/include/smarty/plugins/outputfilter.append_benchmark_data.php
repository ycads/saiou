<?php
/**
 * Smarty plugin
 * @package Smarty
 * @subpackage plugins
 */


function smarty_outputfilter_append_benchmark_data($source, &$smarty) 
{ 
  return $source; 
} 

?>
