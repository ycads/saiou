<?php /* Smarty version 2.6.26, created on 2016-03-24 21:34:09
         compiled from inc/ur_here.tpl */ ?>
<div class="urHere"><?php echo $this->_tpl_vars['lang']['ur_here']; ?>
：<a href="<?php echo $this->_tpl_vars['site']['root_url']; ?>
"><?php echo $this->_tpl_vars['lang']['home']; ?>
</a><?php if ($this->_tpl_vars['ur_here']): ?><b>></b><?php echo $this->_tpl_vars['ur_here']; ?>
<?php endif; ?></div>