<?php /* Smarty version 2.6.26, created on 2016-03-24 21:35:25
         compiled from inc/ur_here.tpl */ ?>
<div class="urHere"><?php echo $this->_tpl_vars['lang']['ur_here']; ?>
：<?php echo $this->_tpl_vars['ur_here']; ?>
</div>