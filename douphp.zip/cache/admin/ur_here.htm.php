<?php /* Smarty version 2.6.26, created on 2016-03-24 21:33:40
         compiled from ur_here.htm */ ?>
<!-- 当前位置 -->
<div id="urHere"><?php echo $this->_tpl_vars['lang']['home']; ?>
<?php if ($this->_tpl_vars['ur_here']): ?><b>></b><strong><?php echo $this->_tpl_vars['ur_here']; ?>
</strong> <?php endif; ?></div>