<?php /* Smarty version 2.6.26, created on 2016-03-25 20:04:28
         compiled from footer.htm */ ?>
<div class="clear"></div>
<div id="dcFooter">
 <div id="footer">
  <div class="line"></div>
  <ul>
   
  </ul>
 </div>
</div><!-- dcFooter 结束 -->
<div class="clear"></div>